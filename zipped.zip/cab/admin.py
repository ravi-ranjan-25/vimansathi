from django.contrib import admin
from cab.models import carClass,cabdetails,cabOrder
# Register your models here.

admin.site.register(carClass)
admin.site.register(cabdetails)
admin.site.register(cabOrder)