from django.apps import AppConfig


class CabConfig(AppConfig):
    name = 'cab'
